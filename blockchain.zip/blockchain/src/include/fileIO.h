#ifndef FILEIO_H
#define FILEIO_H

#include "util.h"
#include "blockchain.h"

iResult write_to_file(Blockchain blockchain);

#endif /* FILEIO_H */