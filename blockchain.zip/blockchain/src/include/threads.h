#ifndef THREADS_H
#define THREADS_H

#include <conio.h>
#include <process.h>

#include "util.h"

#define MAX_THREADS  32

#endif /* THREADS_H */